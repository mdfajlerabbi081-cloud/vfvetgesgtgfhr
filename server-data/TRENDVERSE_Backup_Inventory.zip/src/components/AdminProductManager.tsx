export { default } from './BlankCustomizableProductManager';
